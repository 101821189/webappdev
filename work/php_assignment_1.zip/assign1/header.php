    <header>
        <nav class="navbar navbar-expand navbar-dark bg-dark sticky-top">
            <a href="index.php" class="navbar-brand">web app dev assignment 1</a>
            <ul class="navbar-nav">
                <li class="nav-item"><a href="postjobform.php" class="nav-link">post a job</a></li>
                <li class="nav-item"><a href="searchjobform.php" class="nav-link">search for a job</a></li>
                <li class="nav-item"><a href="about.php" class="nav-link">about</a></li>
            </ul>
        </nav>
    </header>