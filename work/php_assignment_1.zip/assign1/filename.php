<?php
    // just where the jobs files are stored
    $dir = "../../data/jobposts";
    $filename = "$dir/jobs.txt";
?>