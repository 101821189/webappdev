scp -r ./* s102084174@mercury.swin.edu.au:~/cos30020/www/htdocs/assign1
